package it.bisumto.placeable.mixin;

import it.bisumto.placeable.Placeable;
import net.minecraft.class_1750;
import net.minecraft.class_2211;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2211.class)
public class BambooBlockMixin {

    // PLACEABLE
    @Inject(method = "canPlaceAt", at = @At("HEAD"), cancellable = true)
    public void canPlantAnywhere(class_2680 blockState, class_4538 world, class_2338 blockPos, CallbackInfoReturnable<Boolean> cir) {
        if (Placeable.isDisable(blockState)) {
            return;
        }

        if (Placeable.isValidFloor(world, blockPos)) {
            cir.setReturnValue(true);
        }
    }

    // PREVENT GROWING
    @Inject(method = "randomTick", at = @At("HEAD"), cancellable = true)
    public void randomTickMixin(class_2680 blockState, class_3218 world, class_2338 blockPos, class_5819 random, CallbackInfo ci) {
        if (Placeable.isDisable(class_2246.field_10108)) {
            return;
        }

        int i = 1;
        while (world.method_8320(blockPos.method_10087(i)).method_27852(class_2246.field_10211)) {
            i++;
        }

        class_2680 floor = world.method_8320(blockPos.method_10087(i));
        if (!floor.method_26164(class_3481.field_15497)) {
            ci.cancel();
        }
    }

    // PLACEMENT STATE
    @Inject(method = "getPlacementState", at = @At("TAIL"), cancellable = true)
    public void getPlacementStateMixin(class_1750 ctx, CallbackInfoReturnable<class_2680> cir) {
        if (Placeable.isDisable(class_2246.field_10108)) {
            return;
        }

        if (Placeable.isValidFloor(ctx.method_8045(), ctx.method_8037())) {
            cir.setReturnValue(class_2246.field_10108.method_9564());
        }
    }
}
