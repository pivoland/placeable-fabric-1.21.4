package it.bisumto.placeable.mixin;

import it.bisumto.placeable.Placeable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Iterator;
import net.minecraft.class_2246;
import net.minecraft.class_2266;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2682;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

@Mixin(class_2266.class)
public class CactusBlockMixin {

    // PLACEABLE
    @Inject(method = "canPlaceAt", at = @At("HEAD"), cancellable = true)
    public void canPlantAnywhere(class_2680 blockState, class_4538 world, class_2338 blockPos, CallbackInfoReturnable<Boolean> cir) {
        if (Placeable.isDisable(blockState)) {
            return;
        }

        Iterator<class_2350> directionIterator = class_2350.class_2353.field_11062.iterator();
        class_2350 direction;
        class_2680 directionBlock;
        do {
            if (!directionIterator.hasNext()) {
                class_2680 underBlockState = world.method_8320(blockPos.method_10074());
                if ((underBlockState.method_27852(class_2246.field_10029) || Placeable.isValidFloor(world, blockPos))
                        && world.method_8316(blockPos.method_10084()).method_15769()) {
                    cir.setReturnValue(true);
                }
                return;
            }

            direction = directionIterator.next();
            directionBlock = world.method_8320(blockPos.method_10093(direction));
        } while (!directionBlock.method_26212(class_2682.field_12294, class_2338.field_10980)
                && !directionBlock.method_26225()
                && !world.method_8316(blockPos.method_10093(direction)).method_15767(class_3486.field_15518));
    }

    // PREVENT GROWING
    @Inject(method = "randomTick", at = @At("HEAD"), cancellable = true)
    public void randomTickMixin(class_2680 blockState, class_3218 world, class_2338 blockPos, class_5819 random, CallbackInfo ci) {
        if (Placeable.isDisable(blockState)) {
            return;
        }

        int i = 1;
        while (i < 3 && world.method_8320(blockPos.method_10087(i)).method_27852(class_2246.field_10029)) {
            ++i;
        }

        class_2338 groundBlockPos = blockPos.method_10087(i);
        class_2680 groundBlockState = world.method_8320(groundBlockPos);
        if (!groundBlockState.method_26164(class_3481.field_15466)) {
            ci.cancel();
        }
    }
}
