package it.bisumto.placeable.mixin;

import it.bisumto.placeable.Placeable;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2311;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2311.class)
public class DeadBushBlockMixin {

    // PLACEABLE
    @Inject(method = "canPlantOnTop", at = @At("HEAD"), cancellable = true)
    public void canPlantAnywhere(class_2680 blockState, class_1922 world, class_2338 blockPos, CallbackInfoReturnable<Boolean> cir) {
        if (Placeable.isDisable(class_2246.field_10428)) {
            return;
        }

        if (Placeable.isValidFloor(blockState, world, blockPos)) {
            cir.setReturnValue(true);
        }
    }
}
