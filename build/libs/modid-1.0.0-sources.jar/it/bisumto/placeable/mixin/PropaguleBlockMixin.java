package it.bisumto.placeable.mixin;

import it.bisumto.placeable.Placeable;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_5819;
import net.minecraft.class_7115;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_7115.class)
public class PropaguleBlockMixin {

    @Shadow
    @Final
    public static class_2746 HANGING;

    // PREVENT GROWING
    @Inject(method = "randomTick", at = @At("HEAD"), cancellable = true)
    public void randomTickMixin(class_2680 blockState, class_3218 world, class_2338 blockPos, class_5819 random, CallbackInfo ci) {
        if (Placeable.isDisable(blockState)) {
            return;
        }

        if (blockState.method_11654(HANGING)) {
            return;
        }

        class_2680 underBlockState = world.method_8320(blockPos.method_10074());
        if (underBlockState.method_26164(class_3481.field_29822) && !underBlockState.method_27852(class_2246.field_10194)) {
            return;
        }

        ci.cancel();
    }
}
