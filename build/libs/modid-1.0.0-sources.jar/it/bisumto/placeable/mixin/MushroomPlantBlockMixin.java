package it.bisumto.placeable.mixin;

import it.bisumto.placeable.Placeable;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2420;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2420.class)
public class MushroomPlantBlockMixin {
    // PLACEABLE
    @Inject(method = "canPlaceAt", at = @At("HEAD"), cancellable = true)
    public void canPlantAnywhere(class_2680 blockState, class_4538 world, class_2338 blockPos, CallbackInfoReturnable<Boolean> cir) {
        if (Placeable.isDisable(blockState)) {
            return;
        }

        if (Placeable.isValidFloor(world, blockPos)) {
            cir.setReturnValue(true);
        }
    }

    // PREVENT GROWING
    @Inject(method = "randomTick", at = @At("HEAD"), cancellable = true)
    public void randomTickMixin(class_2680 blockState, class_3218 world, class_2338 blockPos, class_5819 random, CallbackInfo ci) {
        if (Placeable.isDisable(blockState)) {
            return;
        }

        if (!world.method_8320(blockPos.method_10069(0, -1, 0)).method_26164(class_3481.field_25739)
                && world.method_22335(blockPos, 0) >= 13) {
            ci.cancel();
            return;
        }

        if (random.method_43048(25) == 0) {
            int i = 5;
            for (class_2338 targetBlockPos : class_2338.method_10097(blockPos.method_10069(-4, -1, -4), blockPos.method_10069(4, 1, 4))) {
                if (world.method_8320(targetBlockPos).method_27852(class_2246.field_10251)
                        || world.method_8320(targetBlockPos).method_27852(class_2246.field_10559)) {
                    --i;
                    if (i <= 0) {
                        ci.cancel();
                        return;
                    }
                }
            }

            class_2338 randomBlockPos = blockPos.method_10069(random.method_43048(3) - 1, random.method_43048(2) - random.method_43048(2), random.method_43048(3) - 1);
            for (int k = 0; k < 4; ++k) {
                class_2338 underBlockPos = randomBlockPos.method_10069(0, -1, 0);
                class_2680 underBlockState = world.method_8320(underBlockPos);
                if (world.method_22347(randomBlockPos)
                        && blockState.method_26184(world, randomBlockPos)
                        && (underBlockState.method_26164(class_3481.field_25739) || world.method_22335(randomBlockPos, 0) < 13)
                ) {
                    blockPos = randomBlockPos;
                }

                randomBlockPos = blockPos.method_10069(random.method_43048(3) - 1, random.method_43048(2) - random.method_43048(2), random.method_43048(3) - 1);
            }

            class_2338 underBlockPos = randomBlockPos.method_10069(0, -1, 0);
            class_2680 underBlockState = world.method_8320(underBlockPos);
            if (world.method_22347(randomBlockPos)
                    && blockState.method_26184(world, randomBlockPos)
                    && (underBlockState.method_26164(class_3481.field_25739) || world.method_22335(randomBlockPos, 0) < 13)
            ) {
                world.method_8652(randomBlockPos, blockState, 2);
            }
        }

        ci.cancel();
    }
}
