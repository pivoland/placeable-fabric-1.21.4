package it.bisumto.placeable.mixin;

import it.bisumto.placeable.Placeable;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2523;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;


@Mixin(class_2523.class)
public class SugarCaneBlockMixin {

    // PLACEABLE
    @Inject(method = "canPlaceAt", at = @At("HEAD"), cancellable = true)
    public void canPlantAnywhere(class_2680 blockState, class_4538 world, class_2338 blockPos, CallbackInfoReturnable<Boolean> cir) {
        if (Placeable.isDisable(blockState)) {
            return;
        }

        if (Placeable.isValidFloor(world, blockPos)) {
            cir.setReturnValue(true);
        }
    }

    // PREVENT GROWING
    @Inject(method = "randomTick", at = @At("HEAD"), cancellable = true)
    public void randomTickMixin(class_2680 blockState, class_3218 world, class_2338 blockPos, class_5819 random, CallbackInfo ci) {
        if (Placeable.isDisable(blockState)) {
            return;
        }

        int i = 1;
        while (i < 3 && world.method_8320(blockPos.method_10087(i)).method_27852(class_2246.field_10424)) {
            ++i;
        }

        class_2338 groundBlockPos = blockPos.method_10087(i);
        class_2680 groundBlockState = world.method_8320(groundBlockPos);
        if (!groundBlockState.method_26164(class_3481.field_29822) && !groundBlockState.method_26164(class_3481.field_15466)) {
            ci.cancel();
            return;
        }

        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_2680 targetBlockState = world.method_8320(groundBlockPos.method_10093(direction));
            class_3610 targetFluidState = world.method_8316(groundBlockPos.method_10093(direction));

            if (targetFluidState.method_15767(class_3486.field_15517) || targetBlockState.method_27852(class_2246.field_10110)) {
                return;
            }
        }

        ci.cancel();
    }
}
