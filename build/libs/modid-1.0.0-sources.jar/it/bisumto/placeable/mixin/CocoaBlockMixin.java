package it.bisumto.placeable.mixin;

import it.bisumto.placeable.Placeable;
import net.minecraft.class_2282;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_4538;
import net.minecraft.class_5431;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static net.minecraft.class_2383.field_11177;

@Mixin(class_2282.class)
public class CocoaBlockMixin {

    // PLACEABLE
    @Inject(method = "canPlaceAt", at = @At("HEAD"), cancellable = true)
    public void canPlantAnywhere(class_2680 blockState, class_4538 world, class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        if (Placeable.isDisable(blockState)) {
            return;
        }

        class_2680 faceBlockState = world.method_8320(pos.method_10093(blockState.method_11654(field_11177)));
        if (faceBlockState.method_30368(world, pos, blockState.method_11654(field_11177), class_5431.field_25824))
            cir.setReturnValue(true);
    }

    // PREVENT GROWING
    @Inject(method = "randomTick", at = @At("HEAD"), cancellable = true)
    public void randomTickMixin(class_2680 blockState, class_3218 world, class_2338 blockPos, class_5819 random, CallbackInfo ci) {
        if (Placeable.isDisable(blockState)) {
            return;
        }

        class_2680 floor = world.method_8320(blockPos.method_10093(blockState.method_11654(field_11177)));
        if (!floor.method_26164(class_3481.field_15474)) {
            ci.cancel();
        }
    }
}
