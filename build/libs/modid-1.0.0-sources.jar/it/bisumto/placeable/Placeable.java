package it.bisumto.placeable;

import it.bisumto.placeable.config.ConfigManager;
import it.bisumto.placeable.config.PlaceableConfig;
import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2806;
import net.minecraft.class_3481;
import net.minecraft.class_4538;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;


public class Placeable implements ModInitializer {
    public static final String MODID = "placeable";
    public static final Logger LOGGER = LoggerFactory.getLogger(MODID);
    private static ConfigManager configManager;

    @Override
    public void onInitialize() {
        long loadTook = System.currentTimeMillis();
        configManager = new ConfigManager();
        configManager.setup();
        LOGGER.info("Mod loaded in {} ms!", System.currentTimeMillis() - loadTook);
    }

    public static boolean isValidFloor(class_4538 world, class_2338 pos) {
        if (world.method_22350(pos).method_12009() != class_2806.field_12803) {
            return false;
        }

        return isValidFloor(world.method_8320(pos.method_10074()), world, pos.method_10074());
    }

    public static boolean isValidFloor(class_2680 floor, class_1922 world, class_2338 pos) {
        return class_2248.method_16361(world, pos) || floor.method_26164(class_3481.field_15503) || floor.method_27852(class_2246.field_10194);
    }

    public static boolean isDisable(class_2680 blockState) {
        return isDisable(blockState.method_26204());
    }

    public static boolean isDisable(class_4538 world, class_2338 blockPos) {
        if (world.method_22350(blockPos).method_12009() != class_2806.field_12803) {
            return true;
        }

        return isDisable(world.method_8320(blockPos));
    }

    public static PlaceableConfig getConfig() {
        return configManager.getPlaceableConfig();
    }

    public static boolean isDisable(class_2248 block) {
        if (getConfig() == null) {
            return true;
        }

        String blockName = class_7923.field_41175.method_10221(block).toString().toLowerCase(Locale.ROOT);
        return getConfig().disablePlants.contains(blockName);
    }
}
